module.exports = {
  env: { browser: true, es2022: true },
  extends: ['eslint:recommended'],
  parserOptions: { sourceType: 'module' },
  rules: { 'no-unused-vars': ['warn', { argsIgnorePattern: '^_' }] }
}
