export default {
  plugins: {
    autoprefixer: {}
  }
}
